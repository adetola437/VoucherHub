abstract class LocalStorage {
  Future<void> saveAccessToken(String token);
  Future<String?> getAccessToken();
  Future<void> clearAccessToken();
  Future<void> saveUserData(String json);
  Future<String?> getUserData();
  Future<void> clearAll();
}
