import 'package:shared_preferences/shared_preferences.dart';

import '../../config/flavor/app_constants.dart';
import 'local_storage.dart';
import 'secure_storage.dart';

class LocalStorageImpl implements LocalStorage {
  final SharedPreferences prefs;
  final SecureStorage secureStorage;

  LocalStorageImpl({required this.prefs, required this.secureStorage});

  @override
  Future<void> saveAccessToken(String token) =>
      secureStorage.write(AppConstants.accessTokenKey, token);

  @override
  Future<String?> getAccessToken() =>
      secureStorage.read(AppConstants.accessTokenKey);

  @override
  Future<void> clearAccessToken() =>
      secureStorage.delete(AppConstants.accessTokenKey);

  @override
  Future<void> saveUserData(String json) async =>
      prefs.setString(AppConstants.userKey, json);

  @override
  Future<String?> getUserData() async =>
      prefs.getString(AppConstants.userKey);

  @override
  Future<void> clearAll() async {
    await secureStorage.deleteAll();
    await prefs.clear();
  }
}
