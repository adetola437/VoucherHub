import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../config/di/app_initializer.dart';
import '../../features/auth/cubit/auth_cubit.dart';
import '../../features/auth/cubit/auth_state.dart';
import '../../features/auth/presentation/screens/login_screen.dart';
import '../../features/checkout/data/models/checkout_model.dart';
import '../../features/products/data/models/product_model.dart';
import '../../features/products/presentation/controllers/product_catalogue.dart';
import '../../features/products/presentation/controllers/product_detail.dart';
import '../../features/cart/presentation/controllers/cart.dart';
import '../../features/checkout/presentation/controllers/checkout.dart';
import '../../features/checkout/presentation/controllers/checkout_result.dart';
import '../../features/orders/presentation/controllers/orders.dart';
import '../../features/orders/presentation/controllers/order_detail.dart';
import '../../features/orders/data/models/order_model.dart';
import '../../features/vouchers/presentation/controllers/vouchers.dart';
import '../../features/vouchers/presentation/controllers/voucher_detail.dart';
import '../../features/vouchers/data/models/voucher_model.dart';
import '../../features/profile/presentation/controllers/profile.dart';
import '../shell/main_shell.dart';

 final rootNavigatorKey = GlobalKey<NavigatorState>(debugLabel: 'root');

class AppRouter {
  AppRouter._();

  // Root navigator: used only for full-screen routes that must appear ABOVE
  // the shell (checkout flow, product detail, order detail, voucher detail).
  
  // static final ScaffoldMessengerState messengerKey = AppMessages.messengerKey.currentState!;

  // One key per tab branch — go_router uses these to preserve each tab's stack.
  static final _catalogueKey =
      GlobalKey<NavigatorState>(debugLabel: 'catalogue');
  static final _cartKey = GlobalKey<NavigatorState>(debugLabel: 'cart');
  static final _ordersKey = GlobalKey<NavigatorState>(debugLabel: 'orders');
  static final _vouchersKey =
      GlobalKey<NavigatorState>(debugLabel: 'vouchers');
  static final _profileKey = GlobalKey<NavigatorState>(debugLabel: 'profile');

  static final router = GoRouter(
    navigatorKey: rootNavigatorKey,
    initialLocation: '/products',
    redirect: (context, state) {
      // Synchronous check — AuthCubit is a lazySingleton so it is always ready.
      final authCubit = sl<AuthCubit>();
      final isLoggedIn = authCubit.state is AuthAuthenticated;
      final isLoginRoute = state.matchedLocation == '/login';

      if (!isLoggedIn && !isLoginRoute) return '/login';
      if (isLoggedIn && isLoginRoute) return '/products';
      return null;
    },
    routes: [
      // ── Full-screen, outside the shell ──────────────────────────────────
      GoRoute(
        path: '/login',
        name: LoginScreen.route,
        parentNavigatorKey: rootNavigatorKey,
        builder: (_, __) => const LoginScreen(),
      ),

      // Product detail — pushes over the shell (no bottom nav)
      GoRoute(
        path: '/products/detail',
        name: ProductDetailScreen.route,
        parentNavigatorKey: rootNavigatorKey,
        builder: (_, state) {
          final product = state.extra as ProductModel;
          return ProductDetailScreen(product: product);
        },
      ),

      // Checkout flow — over the shell
      GoRoute(
        path: '/checkout',
        name: CheckoutScreen.route,
        parentNavigatorKey: rootNavigatorKey,
        builder: (_, __) => const CheckoutScreen(),
      ),
      GoRoute(
        path: '/checkout/result',
        name: CheckoutResultScreen.route,
        parentNavigatorKey: rootNavigatorKey,
        builder: (_, state) {
          final result = state.extra as CheckoutResultModel;
          return CheckoutResultScreen(result: result);
        },
      ),

      // Order detail — over the shell
      GoRoute(
        path: '/orders/detail',
        name: OrderDetailScreen.route,
        parentNavigatorKey: rootNavigatorKey,
        builder: (_, state) {
          final order = state.extra as OrderModel;
          return OrderDetailScreen(order: order);
        },
      ),

      // Voucher detail — over the shell
      GoRoute(
        path: '/vouchers/detail',
        name: VoucherDetailScreen.route,
        parentNavigatorKey: rootNavigatorKey,
        builder: (_, state) {
          final voucher = state.extra as VoucherModel;
          return VoucherDetailScreen(voucher: voucher);
        },
      ),

      // ── Shell: bottom nav lives here ────────────────────────────────────
      StatefulShellRoute.indexedStack(
        builder: (context, state, navigationShell) =>
            MainShell(navigationShell: navigationShell),
        branches: [
          // Tab 0 — Catalogue
          StatefulShellBranch(
            navigatorKey: _catalogueKey,
            routes: [
              GoRoute(
                path: '/products',
                name: ProductCatalogueScreen.route,
                builder: (_, __) => const ProductCatalogueScreen(),
              ),
            ],
          ),

          // Tab 1 — Cart
          StatefulShellBranch(
            navigatorKey: _cartKey,
            routes: [
              GoRoute(
                path: '/cart',
                name: CartScreen.route,
                builder: (_, __) => const CartScreen(),
              ),
            ],
          ),

          // Tab 2 — Orders
          StatefulShellBranch(
            navigatorKey: _ordersKey,
            routes: [
              GoRoute(
                path: '/orders',
                name: OrdersScreen.route,
                builder: (_, __) => const OrdersScreen(),
              ),
            ],
          ),

          // Tab 3 — Vouchers
          StatefulShellBranch(
            navigatorKey: _vouchersKey,
            routes: [
              GoRoute(
                path: '/vouchers',
                name: VouchersScreen.route,
                builder: (_, __) => const VouchersScreen(),
              ),
            ],
          ),

          // Tab 4 — Profile
          StatefulShellBranch(
            navigatorKey: _profileKey,
            routes: [
              GoRoute(
                path: '/profile',
                name: ProfileScreen.route,
                builder: (_, __) => const ProfileScreen(),
              ),
            ],
          ),
        ],
      ),
    ],
  );
}