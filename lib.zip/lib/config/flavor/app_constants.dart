class AppConstants {
  AppConstants._();

  static const String baseUrl = 'https://assessment.suregifts.com.ng/api';
  static const String swaggerUrl = 'https://assessment.suregifts.com.ng/swagger';

  // Storage keys
  static const String accessTokenKey = 'access_token';
  static const String userKey = 'user_data';

  // Timeouts
  static const Duration connectTimeout = Duration(seconds: 30);
  static const Duration sendTimeout = Duration(seconds: 30);
  static const Duration receiveTimeout = Duration(seconds: 30);
}
