import 'package:dartz/dartz.dart';
import '../../../../core/api/exception/failure.dart';
import '../models/product_model.dart';

abstract class IProductsRepository {
  Future<Either<Failure, List<ProductModel>>> getProducts();
  Future<Either<Failure, ProductModel>> getProductById(String productId);
}
