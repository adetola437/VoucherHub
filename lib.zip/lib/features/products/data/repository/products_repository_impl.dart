import 'package:dartz/dartz.dart';
import '../../../../core/api/exception/failure.dart';
import '../datasources/remote/products_remote_datasource.dart';
import '../models/product_model.dart';
import 'products_repository.dart';

class ProductsRepositoryImpl implements IProductsRepository {
  final IProductsRemoteDataSource remoteDataSource;
  ProductsRepositoryImpl({required this.remoteDataSource});

  @override
  Future<Either<Failure, List<ProductModel>>> getProducts() =>
      remoteDataSource.getProducts();

  @override
  Future<Either<Failure, ProductModel>> getProductById(String productId) =>
      remoteDataSource.getProductById(productId);
}
