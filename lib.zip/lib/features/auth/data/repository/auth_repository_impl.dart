import 'package:dartz/dartz.dart';
import 'package:voucher_hub/features/auth/data/models/login_data.dart';
import '../../../../core/api/exception/failure.dart';
import '../../../../core/api/client/api_client.dart';
import '../../../../core/storage/local_storage.dart';
import '../datasources/remote/auth_remote_datasource.dart';
import '../models/auth_models.dart';
import 'auth_repository.dart';

class AuthRepositoryImpl implements IAuthRepository {
  final IAuthRemoteDataSource remoteDataSource;
  final LocalStorage localStorage;

  AuthRepositoryImpl({
    required this.remoteDataSource,
    required this.localStorage,
  });

  @override
  Future<Either<Failure, LoginResponse>> login(String email, String password) async {
    return await remoteDataSource.login(email, password);
  }

  @override
  Future<void> logout() async {
    await localStorage.clearAll();
  }

  @override
  Future<String?> getSavedToken() => localStorage.getAccessToken();
}
