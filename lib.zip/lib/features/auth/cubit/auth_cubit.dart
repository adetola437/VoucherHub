import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../config/di/app_initializer.dart';
import '../../../core/api/client/api_client.dart';
import '../data/repository/auth_repository.dart';
import 'auth_state.dart';

class AuthCubit extends Cubit<AuthState> {
  final IAuthRepository repository;

  AuthCubit({required this.repository}) : super(AuthInitial()) {
    _checkSavedSession();
  }

  Future<void> _checkSavedSession() async {
    final token = await repository.getSavedToken();
    if (token != null && token.isNotEmpty) {
      // Re-apply token to Dio so interceptor picks it up
      sl<IApiClient>().setToken(token);
      // We don't have user details without a /me endpoint,
      // so we emit a minimal authenticated state
      // emit(AuthAuthenticated(AuthUser(accessToken: token)));
    }
    // For now, require fresh login every session
    emit(AuthUnauthenticated());
  }

  Future<void> login(String email, String password) async {
    emit(AuthLoading());
    final result = await repository.login(email, password);
    result.fold(
      (failure) => emit(AuthError(failure.message)),
      (user) {
        sl<IApiClient>().setToken(user.accessToken);
        emit(AuthAuthenticated(user.user));
      },
    );
  }

  Future<void> logout() async {
    await repository.logout();
    sl<IApiClient>().clearToken();
    emit(AuthUnauthenticated());
  }
}
